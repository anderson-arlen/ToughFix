Public NGA EGM96 coefficient excerpt, degrees 2 through 8, plus the first degree 9 row.
